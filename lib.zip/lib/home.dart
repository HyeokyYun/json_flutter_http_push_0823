import 'dart:convert';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart';
import 'package:json_flutter_http_push_0819/login.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  final String currentUserId;
  const HomeScreen({Key? key, required this.currentUserId}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState(currentUserId: currentUserId);
}

class _HomeScreenState extends State<HomeScreen> {
  _HomeScreenState({Key? key, required this.currentUserId});
  final currentUserId;
  String? _token;

  bool isSent = false;

  late FirebaseMessaging messaging;

  final GoogleSignIn googleSignIn = GoogleSignIn();

  @override
  void initState(){
    super.initState();
    messaging = FirebaseMessaging.instance;
    messaging.getToken().then((value){
      _token = value;
      print("token: $_token");
      FirebaseFirestore.instance.collection('users').doc(currentUserId).update(
          {'userToken': value});
    });
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Home'),
        ),
        body: Center(
          child: Column(
            children: [
              Text('User Profile'),
              Text(currentUserId),
              //Text(_token!),
              ElevatedButton(onPressed: () async {
                await FirebaseAuth.instance.signOut();
                await googleSignIn.disconnect();
                await googleSignIn.signOut();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
              },
                  child: Text('Sign Out')),
              ElevatedButton(onPressed: () async {
                await sendNotification(currentUserId, 'Test Title', 'Test Body');
              },
                  child: Text('Send Message')
              ),
            ],
          ),
        ),
    );
  }
  // String FCM(String token){
  //   return jsonEncode({
  //     'notification': {
  //       'title': 'Hello World',
  //       'body': 'Test Notification'
  //     },
  //     'data':{
  //       'click_action' : 'FLUTTER_NOTIFICATION_CLICK',
  //       'id': '1',
  //     },
  //     'to': token,
  //   });
  // }

  Future sendNotification(String userId, String title, String message) async {
    try {
      //DocumentSnapshot<Map<String, dynamic>> ds = await FirebaseFirestore.instance.collection("fcm").doc(userId).get();
      if (_token != null) {
        String token = _token!;
        await post(
          Uri.parse('https://fcm.googleapis.com/fcm/send'),
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'key=AAAAKpR1cYA:APA91bF6I5RtFTbxe_y8QXwIyTBszaoZuEb8wxSeqQWTZhIUMFEIHZ8jlxsDUlVPb8wyZuuuXEmYkcZVcd8vEzHQfE-9FPHKSyKbcZrxcQ75bTVYDP6i6MnjCuHv6VGmkzsWZMQR7RWV', // replace $serverToken with your firebase messaging server token
          },
          body: jsonEncode(
            <String, dynamic>{
              'notification': <String, dynamic>{'body': message, 'title': title},
              'priority': 'high',
              'data': <String, dynamic>{
                'click_action': 'FLUTTER_NOTIFICATION_CLICK',
                'id': '1',
                'status': 'done',
                'view': 'orders'},
              'to': token,
            },
          ),
        );
      } else {
        print("unable to fetch admin device token from database");
      }
    } catch (e) {
      print("Error in sending notification");
      print(e);
    }
  }

// Future<void> sendPushMessage() async{
  //   if(_token == null){
  //     print('Unable to send FCM message, no token exits.');
  //     return;
  //   }
  //   try{
  //     await http.post(
  //       Uri.parse('https://api.rnfirebase.io/messaging/send'),
  //       headers: <String, String>{
  //         'Content-Type' :'applicatoin/json; charset=UTF-8',
  //         'Authorization': 'key = AAAAKpR1cYA:APA91bF6I5RtFTbxe_y8QXwIyTBszaoZuEb8wxSeqQWTZhIUMFEIHZ8jlxsDUlVPb8wyZuuuXEmYkcZVcd8vEzHQfE-9FPHKSyKbcZrxcQ75bTVYDP6i6MnjCuHv6VGmkzsWZMQR7RWV'
  //       },
  //       body: FCM(_token!),
  //     );
  //     //Fluttertoast.showToast(msg: FCM(_token!));
  //     print('${FCM(_token!)}');
  //   } catch (e) {
  //     print(e);
  //   }
  // }
  // void _createPost(String token) async {
  //   String url = 'https://fcm.googleapis.com/fcm/send';
  //
  //   final serverKey = await http.post('https://fcm.googleapis.com/fcm/send',
  //     body: jsonEncode({
  //       'to': token,
  //       'notification':{
  //         'title': "FMC",
  //         'body': "messaging tuturoal"
  //       },
  //       'data':{
  //         'msgId': 'msg_1234'
  //       }
  //     },),
  //     headers: {'Content-Type': "applicatoin/json"},
  //   );
  //   final Post paresedReponse = Post.fromJSON(jsonDecode(serverKey.body));
  // }

}
